#pragma once
#include "StaticObject.h"
class Spike : public StaticObject
{
public:
	Spike(const sf::Sprite& sprite,const sf::FloatRect& rect);

};

