#include "Constants.h"
int MAX_LEVELS_NO = 3;
int S_HEIGHT = 2000 * 0.8;
int S_WIDTH = 3000 * 0.7;