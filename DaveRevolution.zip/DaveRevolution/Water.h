#pragma once
#include "StaticObject.h"
class Water :public StaticObject
{
public:
	Water(const sf::Sprite& sprite,const sf::FloatRect& rect);

};

