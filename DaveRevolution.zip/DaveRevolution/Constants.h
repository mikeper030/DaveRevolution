#pragma once


 enum directions {
	Idle, Right, Left, Jump, Crouch, IdleRight, IdleLeft,Shoot,Stand
};

 extern int MAX_LEVELS_NO;
 extern int S_HEIGHT;
 extern int S_WIDTH;